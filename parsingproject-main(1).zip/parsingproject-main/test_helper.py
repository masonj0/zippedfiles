def say_hello():
  return "Hello from the helper file!"
