from test_helper import say_hello

def run_test():
  message = say_hello()
  print(message)

if __name__ == "__main__":
  run_test()
